################################################
PlastikOpera
################################################

The main KDE settings which this Skin was designed for are:

Style:       Plastik
Icons:       Crystal SVG
             with icon size 22 for toolbars and 16 for small icons
Color Theme: KDE 3.4 default

The file check.sh is a bash script that check for files used in skin.ini 
but not do not exist in the theme directory (missing files) and for files that 
exist in the theme directory but have no reference in skin.ini (unused files).

This theme inherit some extra button icons from the KDE-HiCrysal 1.03 theme, 
you have to modify toolbar.ini in order to make use of them. An example 
configuration provided from Soenke Dibbern follows.

[Customize Toolbar Custom.content]
Button0, 51212=Refresh display
Button1, 44002=View frame source | View document source
Button2, "Stylesheet"="Go to link element, "stylesheet", , , "View CSS""
Button3, 11456=Manage cookies
Button4, 51099=Work offline | Work online
Button5, 162000="Show popup menu, "Quick Preferences Menu", , , "Quick Preferences Menu""
Button6, 52209=Enable cookies > Disable cookies
Button7, 25164=Clear disk cache
Button8, 67362=Mark all as read
Button9, 20125="Go to parent directory, , , , "Parent Folder""
Button10, "Open in FF"="Execute program, "firefox", "%u", , "InFF""
Button11, "Open in KQ"="Execute program, "konqueror", "%u", , "InKQ""
Button12, "Open in Moz"="Execute program, "mozilla", "%u", , "InMoz""
Button13, "Old preferences"="Show preferences, 100, , , "Show old preferences""
Button14, "Cookies"="Show preferences, 21, , , "Cookies""
	# The following from http://nontroppo.org/wiki/PowerButtons#highlight
Button15, "Find&Mark"="Go to page, "javascript: (function(){var count=0,text,dv;text=prompt('Search phrase:','');if(text==null || text.length==0)return;dv=document.defaultView;function searchWithinNode(node,te,len){var pos,skip,spannode,middlebit,endbit,middleclone;skip=0;if(node.nodeType==3){pos=node.data.toUpperCase().indexOf(te);if(pos>=0){spannode=document.createElement('SPAN');spannode.style.backgroundColor='yellow';middlebit=node.splitText(pos);endbit=middlebit.splitText(len);middleclone=middlebit.cloneNode(true);spannode.appendChild(middleclone);middlebit.parentNode.replaceChild(spannode,middlebit);++count;skip=1;}}else if(node.nodeType==1&& node.childNodes && node.tagName.toUpperCase()!='SCRIPT' && node.tagName.toUpperCase!='STYLE'){for (var child=0;child<node.childNodes.length;++child){child=child+searchWithinNode(node.childNodes[child],te,len);}}return skip;};searchWithinNode(document.body,text.toUpperCase(),text.length);})();", , , "Search and mark""
	# This button has to be placed onto the main bar:
Button16, 26515="Read mail & Get mail & Set alignment, "hotlist", 6 & Focus panel, "mail" + Show popup menu, "Internal Access Points""
	# Mainly useful in Windows
Button17, 69896=Hide opera
Button18, "Open in IE"="Execute program, "iexplore", "%u", , "InIE""
Button29, "GnuPG"="Execute program, "winpt", , , "GnuPG""

There are even some extra icons in order to
support Nontroppo's Web Development Setup (V1.11)
(see http://nontroppo.org/wiki/WebDevToolbar)

################################################
Changelog:
################################################

Version 1.00: First public release
Version 1.01: Progressbar is now a TileBox
Version 1.10: Fork between SUSE and KDE color theme
              Completely remade pushbuttons
              Fixed bottom, left and right pagebar
              Hotlist buttons merged with pushbuttons
              Completed horizontal scrollbar
Version 1.11: Changed bottom of hotlist toggle button
              Changed notify window
              Fixed progress bar color
              Added gradient for tab buttons
              Increased max pagebar button width
              Better yellow-colored security button
              Popup header fixed:
                 insecure (mostly) clones toolabar button,
                 secure (mostly) clones security button
Version 1.12: Dropdown button center fixed (taller image)
              Added gradient for bottom tab button
              Redraw edit tilebox (especially right and bottom)
              Fixed text color for pagebar
              Changed notify window (again)
              Decreased pagebar button and hotlist selector button paddings
Version 1.13: Added "Clear" button
Version 1.14: Added "Go" button using enter.png.
              Removed a lot of unused files, saved 20KB.
              Changed none, sortup and sortdown images

###############################################
Known bugs and glitches:
################################################

* In tabbed dialogs the top left corner of the inner box has two 
  spurious pixels that I wasn't able to remove. 
* The splitter between the hotlist and the locationbar is far from perfect
* Hover animation is missing for dropdown boxes
* Pressed animation is missing for dropdown boxes. 

