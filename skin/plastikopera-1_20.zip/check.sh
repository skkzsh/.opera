#!/bin/sh


doit=

[ "x$1" = x--cleanup ] && doit=Y


echo '################################################'

echo 'Missing files:'

echo '################################################'

egrep -i '\.(png|gif|jpg|jpeg)' skin.ini | awk '

{

  sub(/^[^=]*=[ \t]*/, "")

  sub(/,.*/, "")

  print

}' | while read f; do

  [ ! -f "$f" ] && echo "$f"

done


echo '################################################'

echo 'Unused files:'

echo '################################################'

find * -type f | egrep -i '\.(png|gif|jpg|jpeg)$' | while read f; do

  if ! grep "=[ \t]*$f" skin.ini >/dev/null 2>&1; then

    echo "$f"

    [ Y = "$doit" ] && rm -f "$f"

  fi

done


echo '################################################'

echo 'Duplicated files:'

echo '################################################'

export doit

find * -type f -print | awk '

BEGIN {

  q = "'\''"

}

{

  name = $0

  cmd = "cksum " q name q

  cmd | getline

  close(cmd)

  sum = $1

  if (names[sum] != "") {

    cmd = "diff -q --binary " q names[sum] q " " q name q " >/dev/null 2>&1"

    if (!system(cmd))

      print name "\n" names[sum] "\n"

    if (ENVIRON["doit"] == "Y") {

      cmd = "ln -f " q names[sum] q " " q name q

      system(cmd)

    }

  }

  names[sum] = name

}'


